# AI Python Studio — Batch 2

This batch upgrades the first prototype into a persistent multi-project workspace.

## Included

- Real project folders and `.py` files on the device.
- Durable app-private storage using `FLET_APP_STORAGE_DATA` (Android data survives app updates).
- Automatic save while editing, plus an explicit Save button.
- Restores the most recently open project and file after an app restart.
- Create and switch projects; create, rename (storage API), and delete Python files.
- Output panel, exception details, and execution offloaded to a worker thread to reduce UI freezing.
- Unit tests for persistence, file operations, input validation, and size limits.

## Important limitations

- The app-private workspace is not yet a public folder visible in Android Files. Uninstalling the app may remove its private data; export/import is a later batch.
- Python execution uses `exec` inside the app process. It is **not sandboxed**. Run only code you trust. A future isolated runner is required before treating this as a secure environment.
- This is not yet a full terminal, pip/package manager, debugger, Git client, or AI/Gemini agent.
- Long-running or infinite user code has no hard timeout yet. `input()` prompts are not implemented yet.
- The storage layer supports file rename, but the current screen does not expose a rename button yet.
- Importing modules from the same project is supported by adding the project folder to `sys.path`. For reliable relative file access, use `Path(__file__).parent` in your scripts.

## Validation

Run tests from this directory with:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

The tests exercise the storage layer without requiring Flet or an Android device. An Android APK build and on-device test are still required before release.

## Apply to GitHub

Replace `src/main.py` and `pyproject.toml`, add `src/workspace.py`, and add `tests/test_workspace.py`. Keep the existing `.github/workflows/build-apk.yml` unchanged for this batch; the current workflow already builds APKs with Python 3.12.
