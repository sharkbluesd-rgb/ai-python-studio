# Batch 2 change log

- Replaced the old in-memory editor structure with a persistent multi-project workspace.
- Added real project folders and `.py` files using Flet's durable app-private storage location.
- Added automatic saves, explicit save, and restoration of the last active project/file.
- Added project creation and switching, file creation/deletion, and storage-layer rename support.
- Added safe project IDs and Python filename validation to prevent path traversal.
- Added atomic file writes, project/file limits, and file-size protection.
- Moved code execution into a dedicated module and offloaded execution to a worker thread.
- Added 15 unit tests and an explicit validation report.
- Updated the dependency range for the Flet 1.x API.
